


export interface Book {
    
    title: string;
    author: string;
    description: string;
    bookId:string;
    price:number;
    rating:number;
    cover:string;
    tags?:string;
    
  }